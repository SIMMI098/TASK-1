import tkinter as tk
from datetime import datetime
import random

# Define the chatbot's responses based on user input
def chatbot_response(user_input):
    # Convert input to lowercase to make it case insensitive
    user_input = user_input.lower()

    # Handle simple responses based on keywords
    if "hello" in user_input or "hi" in user_input:
        return "Hello! How can I assist you today?"
    elif "how are you" in user_input:
        return "I'm doing well, thank you for asking!"
    elif "bye" in user_input:
        return "Goodbye! Have a great day!"
    elif "name" in user_input:
        return "I am a chatbot created to help you."
    elif "your name" in user_input:
        return "I am your helpful chatbot!"
    elif "thank you" in user_input or "thanks" in user_input:
        return "You're welcome! Let me know if you need anything else."
    elif "help" in user_input and ("can" in user_input or "need" in user_input):
        return "Sure, how can I help you? Please ask your question."
    elif "help" in user_input:
        return "It seems like you need help! Please specify your question."
    elif "time" in user_input:
        return get_time()
    elif "date" in user_input:
        return get_date()
    elif "joke" in user_input:
        return tell_joke()
    elif any(op in user_input for op in ['+', '-', '*', '/', '%']):
        return calculate_expression(user_input)
    elif "weather" in user_input:
        return get_weather()
    else:
        return "I'm sorry, I didn't understand that. Can you please rephrase?"

# current time
def get_time():
    current_time = datetime.now().strftime("%H:%M:%S")
    return f"The current time is {current_time}."

# current date
def get_date():
    current_date = datetime.now().strftime("%Y-%m-%d")
    return f"Today's date is {current_date}."

#  joke
def tell_joke():
    jokes = [
        "Why don't skeletons fight each other? They don't have the guts.",
        "Why don't programmers like nature? It has too many bugs.",
        "Why did the scarecrow win an award? Because he was outstanding in his field."
    ]
    return random.choice(jokes)

# Handle math expressions
def calculate_expression(expression):
    try:
        result = eval(expression)
        return f"The result is: {result}"
    except Exception as e:
        return "Sorry, I couldn't process that. Please check the input."

# Weather response (simple predefined message)
def get_weather():
    return "The weather is nice today! But please check a weather service for accurate info."

# Define the function that will be called when the user presses the Send button
def send_message():
    user_input = entry.get()
    if user_input.strip() != "":  # Check if the input is not empty
        chat_box.config(state=tk.NORMAL)  # Enable the chatbox to add text
        chat_box.insert(tk.END, f"You: {user_input}\n")
        response = chatbot_response(user_input)
        chat_box.insert(tk.END, f"Bot: {response}\n")
        chat_box.config(state=tk.DISABLED)  # Disable the chatbox again
        chat_box.yview(tk.END)  # Scroll to the bottom to show the latest messages
    entry.delete(0, tk.END)  # Clear the input field

# Create the main window using Tkinter
root = tk.Tk()
root.title("Simple Chatbot")

# Create a scrollable chat box
chat_box = tk.Text(root, height=15, width=50, wrap=tk.WORD, state=tk.DISABLED)
chat_box.pack(pady=10)

# Create the text entry field
entry = tk.Entry(root, width=40)
entry.pack(pady=10)

# Create a Send button
send_button = tk.Button(root, text="Send", command=send_message)
send_button.pack()

# Run the main loop
root.mainloop()
